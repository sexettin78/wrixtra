# wrixtra
Wrixtra açık kaynaklı bir kod editörüdür


Wrixtrayı çalıştırmak için;
İlk öncelikle wrixtra dosyasını açıyoruz sonra önümüze "bin" adında bir klasör gelecek
o klasörü de açıyoruz,karşımıza "Debug" adında bir klasör gelecek
O klasörü de açtıktan sonra karşımıza wrixtra.exe dosyası çıkıyor.
Dosyaya çift tıklayıp çalıştırabilirsiniz isterseniz kısayol oluşturabilirsiniz.

Kodlara bakmak için visual studyo ile ana dizindeki wrixtra.sln dosyasını açın,tüm proje önünüzde.Tamamen açık kaynak.

Yapımcı Sexettin
Resimlerin tamamı https://iconarchive.com sitesindeki herkese açık olan ve ticari kullanımı onaylanmış resimlerdir.
