﻿namespace wrixtra
{
    partial class wrixtra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(wrixtra));
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dosyaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.dosyaAçToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dosyaKaydetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yeniDosyaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.temizleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.çıkışToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dosyaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.birÖncekiİşlemeDönToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.birSonrakiİşlemeDönToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.temizleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kopyalaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yapıştırToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tümünüSeçToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ayarlarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programdanÇıkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.arkaplanRengiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maviToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yeşilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kırmızıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.turuncuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sarıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.morToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.beyazToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.açıkMaviToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.siyahToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pembeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yazıRengiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maviToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.yeşilToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.kırmızıToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.turuncuToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sarıToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.morToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.beyazToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.açıkMaviToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.siyahToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pembeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.öNEMLİBİLGİToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yazıBüyüklüToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.yazıBiçimiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kalınToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.italikToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.altıÇiziliToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.strikeoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yardımToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yapımcıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sürümToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.githubToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ekstraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.görünmezModToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.açToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kapatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.karakterSayısıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.richTextBox1.Location = new System.Drawing.Point(0, 47);
            this.richTextBox1.MaxLength = 2000000;
            this.richTextBox1.MinimumSize = new System.Drawing.Size(960, 450);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(1119, 575);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dosyaToolStripMenuItem1,
            this.dosyaToolStripMenuItem,
            this.ayarlarToolStripMenuItem,
            this.yardımToolStripMenuItem,
            this.ekstraToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1119, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // dosyaToolStripMenuItem1
            // 
            this.dosyaToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dosyaAçToolStripMenuItem,
            this.dosyaKaydetToolStripMenuItem,
            this.yeniDosyaToolStripMenuItem,
            this.temizleToolStripMenuItem1,
            this.çıkışToolStripMenuItem});
            this.dosyaToolStripMenuItem1.Image = global::wrixtra.Properties.Resources.Actions_document_save_icon;
            this.dosyaToolStripMenuItem1.Name = "dosyaToolStripMenuItem1";
            this.dosyaToolStripMenuItem1.Size = new System.Drawing.Size(67, 20);
            this.dosyaToolStripMenuItem1.Text = "Dosya";
            // 
            // dosyaAçToolStripMenuItem
            // 
            this.dosyaAçToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Actions_file_open_icon;
            this.dosyaAçToolStripMenuItem.Name = "dosyaAçToolStripMenuItem";
            this.dosyaAçToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.dosyaAçToolStripMenuItem.Text = "Dosya Aç";
            this.dosyaAçToolStripMenuItem.Click += new System.EventHandler(this.dosyaAçToolStripMenuItem_Click);
            // 
            // dosyaKaydetToolStripMenuItem
            // 
            this.dosyaKaydetToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Actions_document_save_icon;
            this.dosyaKaydetToolStripMenuItem.Name = "dosyaKaydetToolStripMenuItem";
            this.dosyaKaydetToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.dosyaKaydetToolStripMenuItem.Text = "Dosya Kaydet";
            this.dosyaKaydetToolStripMenuItem.Click += new System.EventHandler(this.dosyaKaydetToolStripMenuItem_Click);
            // 
            // yeniDosyaToolStripMenuItem
            // 
            this.yeniDosyaToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Actions_appointment_new_icon;
            this.yeniDosyaToolStripMenuItem.Name = "yeniDosyaToolStripMenuItem";
            this.yeniDosyaToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.yeniDosyaToolStripMenuItem.Text = "Yeni Dosya";
            this.yeniDosyaToolStripMenuItem.Click += new System.EventHandler(this.yeniDosyaToolStripMenuItem_Click_1);
            // 
            // temizleToolStripMenuItem1
            // 
            this.temizleToolStripMenuItem1.Image = global::wrixtra.Properties.Resources.Actions_edit_clear_icon;
            this.temizleToolStripMenuItem1.Name = "temizleToolStripMenuItem1";
            this.temizleToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.temizleToolStripMenuItem1.Text = "Temizle";
            this.temizleToolStripMenuItem1.Click += new System.EventHandler(this.temizleToolStripMenuItem1_Click);
            // 
            // çıkışToolStripMenuItem
            // 
            this.çıkışToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Actions_session_exit_icon;
            this.çıkışToolStripMenuItem.Name = "çıkışToolStripMenuItem";
            this.çıkışToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.çıkışToolStripMenuItem.Text = "Çıkış Alt+F4";
            this.çıkışToolStripMenuItem.Click += new System.EventHandler(this.çıkışToolStripMenuItem_Click_1);
            // 
            // dosyaToolStripMenuItem
            // 
            this.dosyaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.birÖncekiİşlemeDönToolStripMenuItem,
            this.birSonrakiİşlemeDönToolStripMenuItem,
            this.kesToolStripMenuItem,
            this.temizleToolStripMenuItem,
            this.kopyalaToolStripMenuItem,
            this.yapıştırToolStripMenuItem,
            this.tümünüSeçToolStripMenuItem});
            this.dosyaToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Categories_preferences_other_icon;
            this.dosyaToolStripMenuItem.Name = "dosyaToolStripMenuItem";
            this.dosyaToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.dosyaToolStripMenuItem.Text = "Araçlar";
            // 
            // birÖncekiİşlemeDönToolStripMenuItem
            // 
            this.birÖncekiİşlemeDönToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Left_2_2_icon;
            this.birÖncekiİşlemeDönToolStripMenuItem.Name = "birÖncekiİşlemeDönToolStripMenuItem";
            this.birÖncekiİşlemeDönToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.birÖncekiİşlemeDönToolStripMenuItem.Text = "Bir önceki işleme dön Ctrl+Z";
            this.birÖncekiİşlemeDönToolStripMenuItem.Click += new System.EventHandler(this.birÖncekiİşlemeDönToolStripMenuItem_Click);
            // 
            // birSonrakiİşlemeDönToolStripMenuItem
            // 
            this.birSonrakiİşlemeDönToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Right_2_2_icon;
            this.birSonrakiİşlemeDönToolStripMenuItem.Name = "birSonrakiİşlemeDönToolStripMenuItem";
            this.birSonrakiİşlemeDönToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.birSonrakiİşlemeDönToolStripMenuItem.Text = "Bir sonraki işleme dön Ctrl+Y";
            this.birSonrakiİşlemeDönToolStripMenuItem.Click += new System.EventHandler(this.birSonrakiİşlemeDönToolStripMenuItem_Click);
            // 
            // kesToolStripMenuItem
            // 
            this.kesToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Scissor_icon;
            this.kesToolStripMenuItem.Name = "kesToolStripMenuItem";
            this.kesToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.kesToolStripMenuItem.Text = "Kes Ctrl+X";
            this.kesToolStripMenuItem.Click += new System.EventHandler(this.kesToolStripMenuItem_Click);
            // 
            // temizleToolStripMenuItem
            // 
            this.temizleToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Actions_edit_clear_icon;
            this.temizleToolStripMenuItem.Name = "temizleToolStripMenuItem";
            this.temizleToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.temizleToolStripMenuItem.Text = "Temizle ";
            this.temizleToolStripMenuItem.Click += new System.EventHandler(this.temizleToolStripMenuItem_Click);
            // 
            // kopyalaToolStripMenuItem
            // 
            this.kopyalaToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Editing_Copy_icon;
            this.kopyalaToolStripMenuItem.Name = "kopyalaToolStripMenuItem";
            this.kopyalaToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.kopyalaToolStripMenuItem.Text = "Kopyala Ctrl+C";
            this.kopyalaToolStripMenuItem.Click += new System.EventHandler(this.kopyalaToolStripMenuItem_Click);
            // 
            // yapıştırToolStripMenuItem
            // 
            this.yapıştırToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Editing_Copy_icon1;
            this.yapıştırToolStripMenuItem.Name = "yapıştırToolStripMenuItem";
            this.yapıştırToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.yapıştırToolStripMenuItem.Text = "Yapıştır Ctrl+V";
            this.yapıştırToolStripMenuItem.Click += new System.EventHandler(this.yapıştırToolStripMenuItem_Click);
            // 
            // tümünüSeçToolStripMenuItem
            // 
            this.tümünüSeçToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Cursor_Select_icon;
            this.tümünüSeçToolStripMenuItem.Name = "tümünüSeçToolStripMenuItem";
            this.tümünüSeçToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.tümünüSeçToolStripMenuItem.Text = "Tümünü seç Ctrl+A";
            this.tümünüSeçToolStripMenuItem.Click += new System.EventHandler(this.tümünüSeçToolStripMenuItem_Click);
            // 
            // ayarlarToolStripMenuItem
            // 
            this.ayarlarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.programdanÇıkToolStripMenuItem,
            this.arkaplanRengiToolStripMenuItem,
            this.yazıRengiToolStripMenuItem,
            this.fontToolStripMenuItem,
            this.yazıBiçimiToolStripMenuItem});
            this.ayarlarToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Settings_icon;
            this.ayarlarToolStripMenuItem.Name = "ayarlarToolStripMenuItem";
            this.ayarlarToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.ayarlarToolStripMenuItem.Text = "Ayarlar";
            // 
            // programdanÇıkToolStripMenuItem
            // 
            this.programdanÇıkToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Actions_session_exit_icon;
            this.programdanÇıkToolStripMenuItem.Name = "programdanÇıkToolStripMenuItem";
            this.programdanÇıkToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.programdanÇıkToolStripMenuItem.Text = "Programdan çık";
            this.programdanÇıkToolStripMenuItem.Click += new System.EventHandler(this.programdanÇıkToolStripMenuItem_Click);
            // 
            // arkaplanRengiToolStripMenuItem
            // 
            this.arkaplanRengiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.maviToolStripMenuItem,
            this.yeşilToolStripMenuItem,
            this.kırmızıToolStripMenuItem,
            this.turuncuToolStripMenuItem,
            this.sarıToolStripMenuItem,
            this.morToolStripMenuItem,
            this.beyazToolStripMenuItem,
            this.açıkMaviToolStripMenuItem,
            this.siyahToolStripMenuItem,
            this.pembeToolStripMenuItem});
            this.arkaplanRengiToolStripMenuItem.Image = global::wrixtra.Properties.Resources.image_icon;
            this.arkaplanRengiToolStripMenuItem.Name = "arkaplanRengiToolStripMenuItem";
            this.arkaplanRengiToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.arkaplanRengiToolStripMenuItem.Text = "Arkaplan rengi";
            // 
            // maviToolStripMenuItem
            // 
            this.maviToolStripMenuItem.Name = "maviToolStripMenuItem";
            this.maviToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.maviToolStripMenuItem.Text = "Mavi";
            this.maviToolStripMenuItem.Click += new System.EventHandler(this.maviToolStripMenuItem_Click);
            // 
            // yeşilToolStripMenuItem
            // 
            this.yeşilToolStripMenuItem.Name = "yeşilToolStripMenuItem";
            this.yeşilToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.yeşilToolStripMenuItem.Text = "Yeşil";
            this.yeşilToolStripMenuItem.Click += new System.EventHandler(this.yeşilToolStripMenuItem_Click);
            // 
            // kırmızıToolStripMenuItem
            // 
            this.kırmızıToolStripMenuItem.Name = "kırmızıToolStripMenuItem";
            this.kırmızıToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.kırmızıToolStripMenuItem.Text = "Kırmızı";
            this.kırmızıToolStripMenuItem.Click += new System.EventHandler(this.kırmızıToolStripMenuItem_Click);
            // 
            // turuncuToolStripMenuItem
            // 
            this.turuncuToolStripMenuItem.Name = "turuncuToolStripMenuItem";
            this.turuncuToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.turuncuToolStripMenuItem.Text = "Turuncu";
            this.turuncuToolStripMenuItem.Click += new System.EventHandler(this.turuncuToolStripMenuItem_Click);
            // 
            // sarıToolStripMenuItem
            // 
            this.sarıToolStripMenuItem.Name = "sarıToolStripMenuItem";
            this.sarıToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.sarıToolStripMenuItem.Text = "Sarı";
            this.sarıToolStripMenuItem.Click += new System.EventHandler(this.sarıToolStripMenuItem_Click);
            // 
            // morToolStripMenuItem
            // 
            this.morToolStripMenuItem.Name = "morToolStripMenuItem";
            this.morToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.morToolStripMenuItem.Text = "Mor";
            this.morToolStripMenuItem.Click += new System.EventHandler(this.morToolStripMenuItem_Click);
            // 
            // beyazToolStripMenuItem
            // 
            this.beyazToolStripMenuItem.Name = "beyazToolStripMenuItem";
            this.beyazToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.beyazToolStripMenuItem.Text = "Beyaz";
            this.beyazToolStripMenuItem.Click += new System.EventHandler(this.beyazToolStripMenuItem_Click);
            // 
            // açıkMaviToolStripMenuItem
            // 
            this.açıkMaviToolStripMenuItem.Name = "açıkMaviToolStripMenuItem";
            this.açıkMaviToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.açıkMaviToolStripMenuItem.Text = "Açık mavi";
            this.açıkMaviToolStripMenuItem.Click += new System.EventHandler(this.açıkMaviToolStripMenuItem_Click);
            // 
            // siyahToolStripMenuItem
            // 
            this.siyahToolStripMenuItem.Name = "siyahToolStripMenuItem";
            this.siyahToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.siyahToolStripMenuItem.Text = "Siyah";
            this.siyahToolStripMenuItem.Click += new System.EventHandler(this.siyahToolStripMenuItem_Click);
            // 
            // pembeToolStripMenuItem
            // 
            this.pembeToolStripMenuItem.Name = "pembeToolStripMenuItem";
            this.pembeToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.pembeToolStripMenuItem.Text = "Pembe";
            this.pembeToolStripMenuItem.Click += new System.EventHandler(this.pembeToolStripMenuItem_Click);
            // 
            // yazıRengiToolStripMenuItem
            // 
            this.yazıRengiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.maviToolStripMenuItem1,
            this.yeşilToolStripMenuItem1,
            this.kırmızıToolStripMenuItem1,
            this.turuncuToolStripMenuItem1,
            this.sarıToolStripMenuItem1,
            this.morToolStripMenuItem1,
            this.beyazToolStripMenuItem1,
            this.açıkMaviToolStripMenuItem1,
            this.siyahToolStripMenuItem1,
            this.pembeToolStripMenuItem1});
            this.yazıRengiToolStripMenuItem.Image = global::wrixtra.Properties.Resources.file_font_icon;
            this.yazıRengiToolStripMenuItem.Name = "yazıRengiToolStripMenuItem";
            this.yazıRengiToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.yazıRengiToolStripMenuItem.Text = "Yazı Rengi";
            // 
            // maviToolStripMenuItem1
            // 
            this.maviToolStripMenuItem1.Name = "maviToolStripMenuItem1";
            this.maviToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.maviToolStripMenuItem1.Text = "Mavi";
            this.maviToolStripMenuItem1.Click += new System.EventHandler(this.maviToolStripMenuItem1_Click);
            // 
            // yeşilToolStripMenuItem1
            // 
            this.yeşilToolStripMenuItem1.Name = "yeşilToolStripMenuItem1";
            this.yeşilToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.yeşilToolStripMenuItem1.Text = "Yeşil";
            this.yeşilToolStripMenuItem1.Click += new System.EventHandler(this.yeşilToolStripMenuItem1_Click);
            // 
            // kırmızıToolStripMenuItem1
            // 
            this.kırmızıToolStripMenuItem1.Name = "kırmızıToolStripMenuItem1";
            this.kırmızıToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.kırmızıToolStripMenuItem1.Text = "Kırmızı";
            this.kırmızıToolStripMenuItem1.Click += new System.EventHandler(this.kırmızıToolStripMenuItem1_Click);
            // 
            // turuncuToolStripMenuItem1
            // 
            this.turuncuToolStripMenuItem1.Name = "turuncuToolStripMenuItem1";
            this.turuncuToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.turuncuToolStripMenuItem1.Text = "Turuncu";
            this.turuncuToolStripMenuItem1.Click += new System.EventHandler(this.turuncuToolStripMenuItem1_Click);
            // 
            // sarıToolStripMenuItem1
            // 
            this.sarıToolStripMenuItem1.Name = "sarıToolStripMenuItem1";
            this.sarıToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.sarıToolStripMenuItem1.Text = "Sarı";
            this.sarıToolStripMenuItem1.Click += new System.EventHandler(this.sarıToolStripMenuItem1_Click);
            // 
            // morToolStripMenuItem1
            // 
            this.morToolStripMenuItem1.Name = "morToolStripMenuItem1";
            this.morToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.morToolStripMenuItem1.Text = "Mor ";
            this.morToolStripMenuItem1.Click += new System.EventHandler(this.morToolStripMenuItem1_Click);
            // 
            // beyazToolStripMenuItem1
            // 
            this.beyazToolStripMenuItem1.Name = "beyazToolStripMenuItem1";
            this.beyazToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.beyazToolStripMenuItem1.Text = "Beyaz";
            this.beyazToolStripMenuItem1.Click += new System.EventHandler(this.beyazToolStripMenuItem1_Click);
            // 
            // açıkMaviToolStripMenuItem1
            // 
            this.açıkMaviToolStripMenuItem1.Name = "açıkMaviToolStripMenuItem1";
            this.açıkMaviToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.açıkMaviToolStripMenuItem1.Text = "Açık mavi";
            this.açıkMaviToolStripMenuItem1.Click += new System.EventHandler(this.açıkMaviToolStripMenuItem1_Click);
            // 
            // siyahToolStripMenuItem1
            // 
            this.siyahToolStripMenuItem1.Name = "siyahToolStripMenuItem1";
            this.siyahToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.siyahToolStripMenuItem1.Text = "Siyah";
            this.siyahToolStripMenuItem1.Click += new System.EventHandler(this.siyahToolStripMenuItem1_Click);
            // 
            // pembeToolStripMenuItem1
            // 
            this.pembeToolStripMenuItem1.Name = "pembeToolStripMenuItem1";
            this.pembeToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.pembeToolStripMenuItem1.Text = "Pembe";
            this.pembeToolStripMenuItem1.Click += new System.EventHandler(this.pembeToolStripMenuItem1_Click);
            // 
            // fontToolStripMenuItem
            // 
            this.fontToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.öNEMLİBİLGİToolStripMenuItem,
            this.yazıBüyüklüToolStripMenuItem,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7,
            this.toolStripMenuItem8,
            this.toolStripMenuItem9,
            this.toolStripMenuItem10});
            this.fontToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Science_Length_icon;
            this.fontToolStripMenuItem.Name = "fontToolStripMenuItem";
            this.fontToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.fontToolStripMenuItem.Text = "Yazı Büyüklüğü";
            this.fontToolStripMenuItem.Click += new System.EventHandler(this.fontToolStripMenuItem_Click);
            // 
            // öNEMLİBİLGİToolStripMenuItem
            // 
            this.öNEMLİBİLGİToolStripMenuItem.Name = "öNEMLİBİLGİToolStripMenuItem";
            this.öNEMLİBİLGİToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.öNEMLİBİLGİToolStripMenuItem.Text = "ÖNEMLİ BİLGİ!!!";
            this.öNEMLİBİLGİToolStripMenuItem.Click += new System.EventHandler(this.öNEMLİBİLGİToolStripMenuItem_Click);
            // 
            // yazıBüyüklüToolStripMenuItem
            // 
            this.yazıBüyüklüToolStripMenuItem.Name = "yazıBüyüklüToolStripMenuItem";
            this.yazıBüyüklüToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.yazıBüyüklüToolStripMenuItem.Text = "5";
            this.yazıBüyüklüToolStripMenuItem.Click += new System.EventHandler(this.yazıBüyüklüToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(157, 22);
            this.toolStripMenuItem2.Text = "10";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(157, 22);
            this.toolStripMenuItem3.Text = "15";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(157, 22);
            this.toolStripMenuItem4.Text = "20";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(157, 22);
            this.toolStripMenuItem5.Text = "25";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(157, 22);
            this.toolStripMenuItem6.Text = "30";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(157, 22);
            this.toolStripMenuItem7.Text = "35";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(157, 22);
            this.toolStripMenuItem8.Text = "40";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(157, 22);
            this.toolStripMenuItem9.Text = "45";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.toolStripMenuItem9_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(157, 22);
            this.toolStripMenuItem10.Text = "50";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // yazıBiçimiToolStripMenuItem
            // 
            this.yazıBiçimiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kalınToolStripMenuItem,
            this.italikToolStripMenuItem,
            this.altıÇiziliToolStripMenuItem,
            this.strikeoutToolStripMenuItem});
            this.yazıBiçimiToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Text_Effect_icon;
            this.yazıBiçimiToolStripMenuItem.Name = "yazıBiçimiToolStripMenuItem";
            this.yazıBiçimiToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.yazıBiçimiToolStripMenuItem.Text = "Yazı Biçimi";
            this.yazıBiçimiToolStripMenuItem.Click += new System.EventHandler(this.yazıBiçimiToolStripMenuItem_Click);
            // 
            // kalınToolStripMenuItem
            // 
            this.kalınToolStripMenuItem.Name = "kalınToolStripMenuItem";
            this.kalınToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.kalınToolStripMenuItem.Text = "Kalın";
            this.kalınToolStripMenuItem.Click += new System.EventHandler(this.kalınToolStripMenuItem_Click);
            // 
            // italikToolStripMenuItem
            // 
            this.italikToolStripMenuItem.Name = "italikToolStripMenuItem";
            this.italikToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.italikToolStripMenuItem.Text = "İtalik";
            this.italikToolStripMenuItem.Click += new System.EventHandler(this.italikToolStripMenuItem_Click);
            // 
            // altıÇiziliToolStripMenuItem
            // 
            this.altıÇiziliToolStripMenuItem.Name = "altıÇiziliToolStripMenuItem";
            this.altıÇiziliToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.altıÇiziliToolStripMenuItem.Text = "Altı Çizili";
            this.altıÇiziliToolStripMenuItem.Click += new System.EventHandler(this.altıÇiziliToolStripMenuItem_Click);
            // 
            // strikeoutToolStripMenuItem
            // 
            this.strikeoutToolStripMenuItem.Name = "strikeoutToolStripMenuItem";
            this.strikeoutToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.strikeoutToolStripMenuItem.Text = "Üstü Çizili";
            this.strikeoutToolStripMenuItem.Click += new System.EventHandler(this.strikeoutToolStripMenuItem_Click);
            // 
            // yardımToolStripMenuItem
            // 
            this.yardımToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yapımcıToolStripMenuItem,
            this.sürümToolStripMenuItem,
            this.githubToolStripMenuItem});
            this.yardımToolStripMenuItem.Image = global::wrixtra.Properties.Resources.sign_info_icon;
            this.yardımToolStripMenuItem.Name = "yardımToolStripMenuItem";
            this.yardımToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.yardımToolStripMenuItem.Text = "Hakkında";
            this.yardımToolStripMenuItem.Click += new System.EventHandler(this.yardımToolStripMenuItem_Click);
            // 
            // yapımcıToolStripMenuItem
            // 
            this.yapımcıToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Users_Administrator_2_icon;
            this.yapımcıToolStripMenuItem.Name = "yapımcıToolStripMenuItem";
            this.yapımcıToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.yapımcıToolStripMenuItem.Text = "Yapımcı";
            this.yapımcıToolStripMenuItem.Click += new System.EventHandler(this.yapımcıToolStripMenuItem_Click);
            // 
            // sürümToolStripMenuItem
            // 
            this.sürümToolStripMenuItem.Image = global::wrixtra.Properties.Resources.sign_info_icon;
            this.sürümToolStripMenuItem.Name = "sürümToolStripMenuItem";
            this.sürümToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.sürümToolStripMenuItem.Text = "Sürüm";
            this.sürümToolStripMenuItem.Click += new System.EventHandler(this.sürümToolStripMenuItem_Click);
            // 
            // githubToolStripMenuItem
            // 
            this.githubToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Cat_icon;
            this.githubToolStripMenuItem.Name = "githubToolStripMenuItem";
            this.githubToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.githubToolStripMenuItem.Text = "Github";
            this.githubToolStripMenuItem.Click += new System.EventHandler(this.githubToolStripMenuItem_Click);
            // 
            // ekstraToolStripMenuItem
            // 
            this.ekstraToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.görünmezModToolStripMenuItem,
            this.karakterSayısıToolStripMenuItem});
            this.ekstraToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Actions_edit_add_icon;
            this.ekstraToolStripMenuItem.Name = "ekstraToolStripMenuItem";
            this.ekstraToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.ekstraToolStripMenuItem.Text = "Ekstra";
            // 
            // görünmezModToolStripMenuItem
            // 
            this.görünmezModToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.açToolStripMenuItem,
            this.kapatToolStripMenuItem});
            this.görünmezModToolStripMenuItem.Image = global::wrixtra.Properties.Resources.ghost_2_icon;
            this.görünmezModToolStripMenuItem.Name = "görünmezModToolStripMenuItem";
            this.görünmezModToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.görünmezModToolStripMenuItem.Text = "Görünmez mod";
            // 
            // açToolStripMenuItem
            // 
            this.açToolStripMenuItem.Name = "açToolStripMenuItem";
            this.açToolStripMenuItem.Size = new System.Drawing.Size(104, 22);
            this.açToolStripMenuItem.Text = "Aç";
            this.açToolStripMenuItem.Click += new System.EventHandler(this.açToolStripMenuItem_Click_1);
            // 
            // kapatToolStripMenuItem
            // 
            this.kapatToolStripMenuItem.Name = "kapatToolStripMenuItem";
            this.kapatToolStripMenuItem.Size = new System.Drawing.Size(104, 22);
            this.kapatToolStripMenuItem.Text = "Kapat";
            this.kapatToolStripMenuItem.Click += new System.EventHandler(this.kapatToolStripMenuItem_Click);
            // 
            // karakterSayısıToolStripMenuItem
            // 
            this.karakterSayısıToolStripMenuItem.Image = global::wrixtra.Properties.Resources.Numbers_1_Black_icon;
            this.karakterSayısıToolStripMenuItem.Name = "karakterSayısıToolStripMenuItem";
            this.karakterSayısıToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.karakterSayısıToolStripMenuItem.Text = "Karakter Sayısı";
            this.karakterSayısıToolStripMenuItem.Click += new System.EventHandler(this.karakterSayısıToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Dosya Yolu:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(78, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 5;
            // 
            // wrixtra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1119, 625);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(1135, 664);
            this.MinimumSize = new System.Drawing.Size(300, 200);
            this.Name = "wrixtra";
            this.Text = "Wrixtra";
            this.Load += new System.EventHandler(this.wrixtra_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dosyaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ayarlarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem programdanÇıkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem arkaplanRengiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maviToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yeşilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kırmızıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem turuncuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sarıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem morToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem beyazToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem açıkMaviToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem siyahToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pembeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yazıRengiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maviToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem yeşilToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem kırmızıToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem turuncuToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sarıToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem morToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem beyazToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem açıkMaviToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem siyahToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem pembeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fontToolStripMenuItem;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.ToolStripMenuItem temizleToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem kesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kopyalaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dosyaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem dosyaAçToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dosyaKaydetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yeniDosyaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem temizleToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem yardımToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem birÖncekiİşlemeDönToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem birSonrakiİşlemeDönToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tümünüSeçToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çıkışToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ekstraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem görünmezModToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem açToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kapatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yapımcıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sürümToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem githubToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem karakterSayısıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yapıştırToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yazıBüyüklüToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem öNEMLİBİLGİToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yazıBiçimiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kalınToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem italikToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem altıÇiziliToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem strikeoutToolStripMenuItem;
    }
}

